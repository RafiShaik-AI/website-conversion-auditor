"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { updateProfile, updateNotifications, updatePlan } from "@/app/actions/settings"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { plans } from "@/lib/plans"
import type { UserSettings } from "@/lib/db/schema"

export function ProfileForm({
  name,
  email,
  company,
}: {
  name: string
  email: string
  company: string
}) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [formName, setFormName] = useState(name)
  const [formCompany, setFormCompany] = useState(company)

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    startTransition(async () => {
      await updateProfile({ name: formName, company: formCompany })
      toast.success("Profile updated")
      router.refresh()
    })
  }

  return (
    <Card className="p-6">
      <h2 className="font-semibold text-foreground">Profile</h2>
      <p className="mt-1 text-sm text-muted-foreground">Update your personal information.</p>
      <form onSubmit={onSubmit} className="mt-5 flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor="name">Name</Label>
          <Input id="name" value={formName} onChange={(e) => setFormName(e.target.value)} required />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" value={email} disabled />
          <p className="text-xs text-muted-foreground">Email cannot be changed.</p>
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="company">Company</Label>
          <Input
            id="company"
            value={formCompany}
            onChange={(e) => setFormCompany(e.target.value)}
            placeholder="Acme Inc."
          />
        </div>
        <div>
          <Button type="submit" disabled={isPending}>
            {isPending ? "Saving..." : "Save changes"}
          </Button>
        </div>
      </form>
    </Card>
  )
}

export function NotificationsForm({ settings }: { settings: UserSettings }) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [emailReports, setEmailReports] = useState(settings.emailReports)
  const [weeklyDigest, setWeeklyDigest] = useState(settings.weeklyDigest)

  const save = (next: { emailReports: boolean; weeklyDigest: boolean }) => {
    startTransition(async () => {
      await updateNotifications(next)
      toast.success("Preferences saved")
      router.refresh()
    })
  }

  return (
    <Card className="p-6">
      <h2 className="font-semibold text-foreground">Notifications</h2>
      <p className="mt-1 text-sm text-muted-foreground">Choose what we email you about.</p>
      <div className="mt-5 flex flex-col gap-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-foreground">Audit completion emails</p>
            <p className="text-sm text-muted-foreground">Get notified when an audit finishes.</p>
          </div>
          <Switch
            checked={emailReports}
            disabled={isPending}
            onCheckedChange={(v) => {
              setEmailReports(v)
              save({ emailReports: v, weeklyDigest })
            }}
          />
        </div>
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-foreground">Weekly digest</p>
            <p className="text-sm text-muted-foreground">A weekly summary of your audit trends.</p>
          </div>
          <Switch
            checked={weeklyDigest}
            disabled={isPending}
            onCheckedChange={(v) => {
              setWeeklyDigest(v)
              save({ emailReports, weeklyDigest: v })
            }}
          />
        </div>
      </div>
    </Card>
  )
}

export function PlanForm({ currentPlan }: { currentPlan: string }) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()

  const change = (planId: "free" | "pro" | "agency") => {
    startTransition(async () => {
      await updatePlan(planId)
      toast.success("Plan updated")
      router.refresh()
    })
  }

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-foreground">Subscription</h2>
          <p className="mt-1 text-sm text-muted-foreground">Manage your current plan.</p>
        </div>
        <Badge variant="secondary" className="capitalize">
          {currentPlan} plan
        </Badge>
      </div>
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {plans.map((plan) => {
          const active = plan.id === currentPlan
          return (
            <div
              key={plan.id}
              className="flex flex-col gap-3 rounded-lg border border-border p-4"
            >
              <div>
                <p className="font-medium text-foreground">{plan.name}</p>
                <p className="text-sm text-muted-foreground">
                  {plan.price}
                  <span className="text-xs">/{plan.period}</span>
                </p>
              </div>
              <Button
                size="sm"
                variant={active ? "secondary" : "outline"}
                disabled={active || isPending}
                onClick={() => change(plan.id)}
              >
                {active ? "Current plan" : `Switch to ${plan.name}`}
              </Button>
            </div>
          )
        })}
      </div>
    </Card>
  )
}
