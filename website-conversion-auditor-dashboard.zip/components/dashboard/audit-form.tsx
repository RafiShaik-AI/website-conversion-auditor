"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Search, Loader2, Sparkles, Gauge, Accessibility } from "lucide-react"
import { toast } from "sonner"
import { runAudit } from "@/app/actions/audits"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const steps = [
  { icon: Search, label: "Fetching page" },
  { icon: Gauge, label: "Scoring SEO & performance" },
  { icon: Accessibility, label: "Checking accessibility" },
  { icon: Sparkles, label: "Generating AI recommendations" },
]

export function AuditForm() {
  const router = useRouter()
  const [url, setUrl] = useState("")
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    startTransition(async () => {
      const result = await runAudit(url)
      if (!result.ok) {
        setError(result.error)
        toast.error("Audit failed")
        return
      }
      toast.success("Audit complete")
      router.push(`/dashboard/audits/${result.id}`)
    })
  }

  return (
    <Card className="p-6">
      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor="url">Website URL</Label>
          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="example.com"
                className="pl-9"
                disabled={isPending}
                required
              />
            </div>
            <Button type="submit" disabled={isPending} className="sm:w-auto">
              {isPending ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Auditing...
                </>
              ) : (
                <>
                  <Search className="size-4" />
                  Run audit
                </>
              )}
            </Button>
          </div>
          {error && (
            <p className="text-sm text-destructive" role="alert">
              {error}
            </p>
          )}
          <p className="text-xs text-muted-foreground">
            Enter any public website. We&apos;ll analyze the live page — this usually takes 10–30 seconds.
          </p>
        </div>
      </form>

      {isPending && (
        <div className="mt-6 flex flex-col gap-3 border-t border-border pt-6">
          {steps.map((step) => (
            <div key={step.label} className="flex items-center gap-3 text-sm text-muted-foreground">
              <step.icon className="size-4 text-primary" />
              {step.label}
              <Loader2 className="size-3.5 animate-spin text-muted-foreground" />
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
