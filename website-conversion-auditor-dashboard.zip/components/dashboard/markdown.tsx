import { Fragment } from "react"

// Minimal, dependency-free Markdown renderer for AI recommendation text.
export function Markdown({ content }: { content: string }) {
  const lines = content.split("\n")
  const blocks: React.ReactNode[] = []
  let listItems: React.ReactNode[] = []
  let key = 0

  const flushList = () => {
    if (listItems.length > 0) {
      blocks.push(
        <ul key={key++} className="my-2 flex list-disc flex-col gap-1.5 pl-5">
          {listItems}
        </ul>,
      )
      listItems = []
    }
  }

  const inline = (text: string) => {
    // bold **text**
    const parts = text.split(/(\*\*[^*]+\*\*)/g)
    return parts.map((part, i) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return (
          <strong key={i} className="font-semibold text-foreground">
            {part.slice(2, -2)}
          </strong>
        )
      }
      return <Fragment key={i}>{part}</Fragment>
    })
  }

  for (const raw of lines) {
    const line = raw.trimEnd()
    if (!line.trim()) {
      flushList()
      continue
    }
    if (/^#{1,6}\s/.test(line)) {
      flushList()
      const text = line.replace(/^#{1,6}\s/, "")
      blocks.push(
        <h3 key={key++} className="mt-4 text-base font-semibold text-foreground first:mt-0">
          {inline(text)}
        </h3>,
      )
    } else if (/^[-*]\s/.test(line)) {
      listItems.push(
        <li key={key++} className="text-sm leading-relaxed text-muted-foreground">
          {inline(line.replace(/^[-*]\s/, ""))}
        </li>,
      )
    } else if (/^\d+\.\s/.test(line)) {
      listItems.push(
        <li key={key++} className="text-sm leading-relaxed text-muted-foreground">
          {inline(line.replace(/^\d+\.\s/, ""))}
        </li>,
      )
    } else {
      flushList()
      blocks.push(
        <p key={key++} className="my-2 text-sm leading-relaxed text-muted-foreground">
          {inline(line)}
        </p>,
      )
    }
  }
  flushList()

  return <div>{blocks}</div>
}
