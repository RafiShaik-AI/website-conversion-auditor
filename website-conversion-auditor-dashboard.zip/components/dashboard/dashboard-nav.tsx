"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Gauge, LayoutDashboard, PlusCircle, Settings, LogOut, CreditCard } from "lucide-react"
import { authClient } from "@/lib/auth-client"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const links = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/dashboard/new", label: "New audit", icon: PlusCircle },
  { href: "/pricing", label: "Plans", icon: CreditCard },
  { href: "/dashboard/settings", label: "Settings", icon: Settings },
]

export function DashboardNav({ name, email }: { name: string; email: string }) {
  const pathname = usePathname()
  const router = useRouter()

  const signOut = async () => {
    await authClient.signOut()
    router.push("/")
    router.refresh()
  }

  return (
    <aside className="flex h-full flex-col gap-6 border-r border-border bg-sidebar p-4">
      <Link href="/dashboard" className="flex items-center gap-2 px-2 font-semibold text-sidebar-foreground">
        <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <Gauge className="size-5" />
        </span>
        Conversion Auditor
      </Link>

      <nav className="flex flex-1 flex-col gap-1">
        {links.map((link) => {
          const active = link.href === "/dashboard" ? pathname === link.href : pathname.startsWith(link.href)
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
              )}
            >
              <link.icon className="size-4" />
              {link.label}
            </Link>
          )
        })}
      </nav>

      <div className="flex flex-col gap-3 border-t border-sidebar-border pt-4">
        <div className="flex items-center justify-between px-1">
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-sidebar-foreground">{name}</p>
            <p className="truncate text-xs text-muted-foreground">{email}</p>
          </div>
          <ThemeToggle />
        </div>
        <Button variant="outline" size="sm" onClick={signOut} className="w-full justify-start">
          <LogOut className="size-4" />
          Sign out
        </Button>
      </div>
    </aside>
  )
}
