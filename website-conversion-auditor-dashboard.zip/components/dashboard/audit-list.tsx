"use client"

import Link from "next/link"
import { useTransition } from "react"
import { useRouter } from "next/navigation"
import { Trash2, ExternalLink, ArrowRight } from "lucide-react"
import { toast } from "sonner"
import { deleteAudit } from "@/app/actions/audits"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Audit } from "@/lib/db/schema"
import { scoreColor } from "@/components/score-ring"
import { cn } from "@/lib/utils"

function ScorePill({ label, score }: { label: string; score: number }) {
  return (
    <div className="flex flex-col items-center">
      <span className="text-base font-semibold tabular-nums" style={{ color: scoreColor(score) }}>
        {score}
      </span>
      <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</span>
    </div>
  )
}

export function AuditList({ audits }: { audits: Audit[] }) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()

  const handleDelete = (id: number) => {
    startTransition(async () => {
      await deleteAudit(id)
      toast.success("Audit deleted")
      router.refresh()
    })
  }

  if (audits.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border bg-card p-12 text-center">
        <p className="font-medium text-foreground">No audits yet</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          Run your first audit to see SEO, accessibility, and performance scores plus AI recommendations.
        </p>
        <Button asChild className="mt-2">
          <Link href="/dashboard/new">
            Run an audit
            <ArrowRight className="size-4" />
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-3">
      {audits.map((audit) => (
        <div
          key={audit.id}
          className={cn(
            "flex flex-col gap-4 rounded-lg border border-border bg-card p-4 sm:flex-row sm:items-center sm:justify-between",
            isPending && "opacity-70",
          )}
        >
          <div className="flex min-w-0 items-center gap-4">
            <div className="flex size-12 shrink-0 flex-col items-center justify-center rounded-md bg-muted">
              <span
                className="text-lg font-semibold tabular-nums"
                style={{ color: scoreColor(audit.overallScore) }}
              >
                {audit.overallScore}
              </span>
            </div>
            <div className="min-w-0">
              <p className="truncate font-medium text-foreground">{audit.url}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(audit.createdAt).toLocaleString(undefined, {
                  dateStyle: "medium",
                  timeStyle: "short",
                })}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between gap-6 sm:justify-end">
            <div className="flex items-center gap-5">
              <ScorePill label="SEO" score={audit.seoScore} />
              <ScorePill label="A11y" score={audit.accessibilityScore} />
              <ScorePill label="Perf" score={audit.performanceScore} />
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" asChild aria-label="View audit">
                <Link href={`/dashboard/audits/${audit.id}`}>
                  <ExternalLink className="size-4" />
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Delete audit"
                disabled={isPending}
                onClick={() => handleDelete(audit.id)}
              >
                <Trash2 className="size-4 text-destructive" />
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
