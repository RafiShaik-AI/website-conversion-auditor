import { cn } from "@/lib/utils"

export function scoreColor(score: number) {
  if (score >= 90) return "var(--chart-1)"
  if (score >= 50) return "var(--chart-4)"
  return "var(--chart-5)"
}

export function scoreLabel(score: number) {
  if (score >= 90) return "Excellent"
  if (score >= 75) return "Good"
  if (score >= 50) return "Needs work"
  return "Poor"
}

export function ScoreRing({
  score,
  size = 120,
  strokeWidth = 10,
  label,
  className,
}: {
  score: number
  size?: number
  strokeWidth?: number
  label?: string
  className?: string
}) {
  const radius = (size - strokeWidth) / 2
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (score / 100) * circumference
  const color = scoreColor(score)

  return (
    <div className={cn("relative inline-flex items-center justify-center", className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden="true">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--muted)"
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-semibold tabular-nums text-foreground" style={{ fontSize: size / 4 }}>
          {score}
        </span>
        {label && <span className="text-xs text-muted-foreground">{label}</span>}
      </div>
    </div>
  )
}
