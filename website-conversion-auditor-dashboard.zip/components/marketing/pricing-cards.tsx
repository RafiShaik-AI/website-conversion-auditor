import Link from "next/link"
import { Check } from "lucide-react"
import { plans } from "@/lib/plans"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

export function PricingCards({ ctaHref = "/sign-up" }: { ctaHref?: string }) {
  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {plans.map((plan) => (
        <Card
          key={plan.id}
          className={cn(
            "relative flex flex-col p-6",
            plan.highlighted && "border-primary shadow-lg ring-1 ring-primary",
          )}
        >
          {plan.highlighted && (
            <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
              Most popular
            </span>
          )}
          <h3 className="text-lg font-semibold text-foreground">{plan.name}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{plan.description}</p>
          <div className="mt-5 flex items-baseline gap-1">
            <span className="text-4xl font-semibold tracking-tight text-foreground">{plan.price}</span>
            <span className="text-sm text-muted-foreground">/{plan.period}</span>
          </div>
          <ul className="mt-6 flex flex-1 flex-col gap-3">
            {plan.features.map((feature) => (
              <li key={feature} className="flex items-start gap-2 text-sm">
                <Check className="mt-0.5 size-4 shrink-0 text-primary" />
                <span className="text-foreground">{feature}</span>
              </li>
            ))}
          </ul>
          <Button asChild className="mt-8 w-full" variant={plan.highlighted ? "default" : "outline"}>
            <Link href={ctaHref}>{plan.cta}</Link>
          </Button>
        </Card>
      ))}
    </div>
  )
}
