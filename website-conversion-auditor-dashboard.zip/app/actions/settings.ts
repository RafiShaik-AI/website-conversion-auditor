"use server"

import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { userSettings, user as userTable } from "@/lib/db/schema"
import { eq } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error("Unauthorized")
  return session.user.id
}

export async function getSettings() {
  const userId = await getUserId()
  const rows = await db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1)
  if (rows[0]) return rows[0]
  const [created] = await db.insert(userSettings).values({ userId }).returning()
  return created
}

export async function updateProfile(formData: { name: string; company: string }) {
  const userId = await getUserId()

  await db
    .update(userTable)
    .set({ name: formData.name, updatedAt: new Date() })
    .where(eq(userTable.id, userId))

  await db
    .insert(userSettings)
    .values({ userId, company: formData.company })
    .onConflictDoUpdate({
      target: userSettings.userId,
      set: { company: formData.company, updatedAt: new Date() },
    })

  revalidatePath("/dashboard/settings")
  return { ok: true as const }
}

export async function updateNotifications(formData: { emailReports: boolean; weeklyDigest: boolean }) {
  const userId = await getUserId()
  await db
    .insert(userSettings)
    .values({ userId, emailReports: formData.emailReports, weeklyDigest: formData.weeklyDigest })
    .onConflictDoUpdate({
      target: userSettings.userId,
      set: { emailReports: formData.emailReports, weeklyDigest: formData.weeklyDigest, updatedAt: new Date() },
    })
  revalidatePath("/dashboard/settings")
  return { ok: true as const }
}

export async function updatePlan(plan: "free" | "pro" | "agency") {
  const userId = await getUserId()
  await db
    .insert(userSettings)
    .values({ userId, plan })
    .onConflictDoUpdate({
      target: userSettings.userId,
      set: { plan, updatedAt: new Date() },
    })
  revalidatePath("/dashboard/settings")
  revalidatePath("/pricing")
  return { ok: true as const }
}
