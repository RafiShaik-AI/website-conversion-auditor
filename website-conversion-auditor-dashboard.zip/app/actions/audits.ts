"use server"

import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { audits } from "@/lib/db/schema"
import { analyzeWebsite } from "@/lib/audit/analyze"
import { generateRecommendations } from "@/lib/audit/recommendations"
import { and, desc, eq } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error("Unauthorized")
  return session.user.id
}

export async function getAudits() {
  const userId = await getUserId()
  return db.select().from(audits).where(eq(audits.userId, userId)).orderBy(desc(audits.createdAt))
}

export async function getAudit(id: number) {
  const userId = await getUserId()
  const rows = await db
    .select()
    .from(audits)
    .where(and(eq(audits.id, id), eq(audits.userId, userId)))
    .limit(1)
  return rows[0] ?? null
}

export type RunAuditResult = { ok: true; id: number } | { ok: false; error: string }

export async function runAudit(rawUrl: string): Promise<RunAuditResult> {
  const userId = await getUserId()

  if (!rawUrl || !rawUrl.trim()) {
    return { ok: false, error: "Please enter a website URL." }
  }

  let analysis
  try {
    analysis = await analyzeWebsite(rawUrl)
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "Audit failed. Please try a different URL." }
  }

  const recommendations = await generateRecommendations(analysis)

  const [inserted] = await db
    .insert(audits)
    .values({
      userId,
      url: analysis.url,
      status: "completed",
      seoScore: analysis.seoScore,
      accessibilityScore: analysis.accessibilityScore,
      performanceScore: analysis.performanceScore,
      overallScore: analysis.overallScore,
      metrics: analysis.metrics,
      issues: analysis.issues,
      recommendations,
    })
    .returning({ id: audits.id })

  revalidatePath("/dashboard")
  return { ok: true, id: inserted.id }
}

export async function deleteAudit(id: number) {
  const userId = await getUserId()
  await db.delete(audits).where(and(eq(audits.id, id), eq(audits.userId, userId)))
  revalidatePath("/dashboard")
}
