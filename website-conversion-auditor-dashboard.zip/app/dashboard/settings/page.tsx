import { headers } from "next/headers"
import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { getSettings } from "@/app/actions/settings"
import { ProfileForm, NotificationsForm, PlanForm } from "@/components/dashboard/settings-forms"

export default async function SettingsPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  const settings = await getSettings()

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-8">
      <h1 className="text-2xl font-semibold tracking-tight text-foreground">Settings</h1>
      <p className="mt-1 text-sm text-muted-foreground">Manage your account, notifications, and subscription.</p>

      <div className="mt-8 flex flex-col gap-6">
        <ProfileForm name={session.user.name} email={session.user.email} company={settings.company ?? ""} />
        <NotificationsForm settings={settings} />
        <PlanForm currentPlan={settings.plan} />
      </div>
    </div>
  )
}
