import { Search, Accessibility, Zap, Sparkles } from "lucide-react"
import { AuditForm } from "@/components/dashboard/audit-form"
import { Card } from "@/components/ui/card"

const checks = [
  { icon: Search, title: "SEO", text: "Title, meta description, headings, content depth, HTTPS." },
  { icon: Accessibility, title: "Accessibility", text: "Alt text, language, viewport, heading structure." },
  { icon: Zap, title: "Performance", text: "Payload size, response time, render-blocking scripts." },
  { icon: Sparkles, title: "AI plan", text: "A prioritized, plain-English action plan for your site." },
]

export default function NewAuditPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-8">
      <h1 className="text-2xl font-semibold tracking-tight text-foreground">New audit</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Scan a website for conversion-killing issues across SEO, accessibility, and performance.
      </p>

      <div className="mt-8">
        <AuditForm />
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {checks.map((check) => (
          <Card key={check.title} className="flex items-start gap-3 p-4">
            <span className="flex size-9 items-center justify-center rounded-lg bg-accent text-accent-foreground">
              <check.icon className="size-4" />
            </span>
            <div>
              <p className="font-medium text-foreground">{check.title}</p>
              <p className="text-sm text-muted-foreground">{check.text}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
