import type React from "react"
import { redirect } from "next/navigation"
import { headers } from "next/headers"
import { auth } from "@/lib/auth"
import { DashboardNav } from "@/components/dashboard/dashboard-nav"
import { MobileTopbar } from "@/components/dashboard/mobile-topbar"

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  return (
    <div className="min-h-svh bg-background lg:grid lg:grid-cols-[260px_1fr]">
      <div className="hidden lg:block lg:h-svh lg:sticky lg:top-0">
        <DashboardNav name={session.user.name} email={session.user.email} />
      </div>
      <MobileTopbar />
      <div className="min-w-0">{children}</div>
    </div>
  )
}
