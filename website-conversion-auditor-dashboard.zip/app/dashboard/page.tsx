import Link from "next/link"
import { PlusCircle, Activity, TrendingUp, Globe } from "lucide-react"
import { getAudits } from "@/app/actions/audits"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { AuditList } from "@/components/dashboard/audit-list"

function StatCard({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
}) {
  return (
    <Card className="flex items-center gap-4 p-5">
      <span className="flex size-11 items-center justify-center rounded-lg bg-accent text-accent-foreground">
        <Icon className="size-5" />
      </span>
      <div>
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="text-2xl font-semibold tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

export default async function DashboardPage() {
  const audits = await getAudits()

  const total = audits.length
  const avgOverall =
    total > 0 ? Math.round(audits.reduce((sum, a) => sum + a.overallScore, 0) / total) : 0
  const uniqueSites = new Set(audits.map((a) => a.url)).size

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">Your website audits and conversion insights.</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/new">
            <PlusCircle className="size-4" />
            New audit
          </Link>
        </Button>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <StatCard icon={Activity} label="Total audits" value={String(total)} />
        <StatCard icon={TrendingUp} label="Average score" value={total > 0 ? String(avgOverall) : "—"} />
        <StatCard icon={Globe} label="Sites audited" value={String(uniqueSites)} />
      </div>

      <div className="mt-10">
        <h2 className="mb-4 text-lg font-semibold text-foreground">Recent audits</h2>
        <AuditList audits={audits} />
      </div>
    </div>
  )
}
