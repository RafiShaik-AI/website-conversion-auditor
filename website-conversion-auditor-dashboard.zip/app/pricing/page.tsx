import type { Metadata } from "next"
import { SiteHeader } from "@/components/marketing/site-header"
import { SiteFooter } from "@/components/marketing/site-footer"
import { PricingCards } from "@/components/marketing/pricing-cards"

export const metadata: Metadata = {
  title: "Pricing — Website Conversion Auditor",
  description: "Simple, transparent pricing. Start free and upgrade as you scale your website audits.",
}

const faqs = [
  {
    q: "Is there really a free plan?",
    a: "Yes. The Starter plan lets you run 5 audits per month with full SEO, accessibility, and performance scoring, forever, at no cost.",
  },
  {
    q: "What counts as an audit?",
    a: "Each time you analyze a website URL, that counts as one audit. Re-running the same URL counts as a new audit.",
  },
  {
    q: "Can I cancel anytime?",
    a: "Absolutely. Plans are month-to-month and you can downgrade or cancel whenever you like — no contracts.",
  },
  {
    q: "Do you offer white-label reports?",
    a: "Yes, the Agency plan includes fully white-label PDF reports you can hand directly to your clients.",
  },
]

export default function PricingPage() {
  return (
    <div className="flex min-h-svh flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
          <div className="mx-auto max-w-2xl text-center">
            <h1 className="text-balance text-4xl font-semibold tracking-tight text-foreground sm:text-5xl">
              Pricing that scales with you
            </h1>
            <p className="mt-4 text-pretty text-lg text-muted-foreground">
              Start free, then upgrade for unlimited audits, AI recommendations, and branded reports.
            </p>
          </div>
          <div className="mt-14">
            <PricingCards />
          </div>
        </section>

        <section className="border-t border-border bg-card/40 py-16 lg:py-24">
          <div className="mx-auto max-w-3xl px-4 sm:px-6">
            <h2 className="text-center text-3xl font-semibold tracking-tight text-foreground">
              Frequently asked questions
            </h2>
            <div className="mt-10 flex flex-col gap-6">
              {faqs.map((faq) => (
                <div key={faq.q} className="rounded-lg border border-border bg-card p-6">
                  <h3 className="font-semibold text-foreground">{faq.q}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
