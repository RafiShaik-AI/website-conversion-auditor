import Link from "next/link"
import { ArrowRight, Search, Accessibility, Zap, Sparkles, FileText, ShieldCheck, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { SiteHeader } from "@/components/marketing/site-header"
import { SiteFooter } from "@/components/marketing/site-footer"
import { PricingCards } from "@/components/marketing/pricing-cards"
import { ScoreRing } from "@/components/score-ring"

const features = [
  {
    icon: Search,
    title: "SEO analysis",
    description: "Titles, meta descriptions, heading structure, content depth and HTTPS — scored against best practices.",
  },
  {
    icon: Accessibility,
    title: "Accessibility checks",
    description: "Catch missing alt text, language attributes, and viewport issues that block real users and hurt compliance.",
  },
  {
    icon: Zap,
    title: "Performance signals",
    description: "Measure payload size, response time, and render-blocking scripts that quietly kill your conversions.",
  },
  {
    icon: Sparkles,
    title: "AI recommendations",
    description: "Get a prioritized, plain-English action plan generated from your audit by an expert AI consultant.",
  },
  {
    icon: FileText,
    title: "PDF reports",
    description: "Export clean, shareable reports for clients and stakeholders in a single click.",
  },
  {
    icon: BarChart3,
    title: "History & trends",
    description: "Track every audit over time and watch your scores climb as you ship improvements.",
  },
]

const steps = [
  { title: "Paste your URL", description: "Drop in any public website address — no setup, no code, no tracking script." },
  { title: "We scan it live", description: "We fetch the page and analyze SEO, accessibility and performance in seconds." },
  { title: "Act on insights", description: "Review scores, read AI recommendations, and export a polished PDF report." },
]

export default function HomePage() {
  return (
    <div className="flex min-h-svh flex-col">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
                <ShieldCheck className="size-3.5 text-primary" />
                Free audit in under 30 seconds
              </span>
              <h1 className="mt-5 text-balance text-4xl font-semibold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
                Find what&apos;s costing you conversions.
              </h1>
              <p className="mt-5 max-w-lg text-pretty text-lg leading-relaxed text-muted-foreground">
                Conversion Auditor scans any website for SEO, accessibility, and performance issues — then hands you an
                AI-powered plan to fix them and convert more visitors.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button size="lg" asChild>
                  <Link href="/sign-up">
                    Run a free audit
                    <ArrowRight className="size-4" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/pricing">View pricing</Link>
                </Button>
              </div>
              <p className="mt-4 text-sm text-muted-foreground">No credit card required.</p>
            </div>

            <HeroPreview />
          </div>
        </section>

        {/* Features */}
        <section id="features" className="border-t border-border bg-card/40 py-16 lg:py-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-balance text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
                Everything you need to optimize conversions
              </h2>
              <p className="mt-4 text-pretty text-muted-foreground">
                One audit covers the three pillars that decide whether a visitor stays, trusts, and converts.
              </p>
            </div>
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {features.map((feature) => (
                <Card key={feature.title} className="p-6">
                  <span className="flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                    <feature.icon className="size-5" />
                  </span>
                  <h3 className="mt-4 font-semibold text-foreground">{feature.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{feature.description}</p>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section id="how-it-works" className="py-16 lg:py-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-balance text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
                From URL to action plan in three steps
              </h2>
            </div>
            <div className="mt-12 grid gap-8 md:grid-cols-3">
              {steps.map((step, i) => (
                <div key={step.title} className="relative">
                  <span className="flex size-10 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-4 font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section className="border-t border-border bg-card/40 py-16 lg:py-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-balance text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
                Simple, transparent pricing
              </h2>
              <p className="mt-4 text-muted-foreground">Start free. Upgrade when you&apos;re ready to scale.</p>
            </div>
            <div className="mt-12">
              <PricingCards />
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 lg:py-24">
          <div className="mx-auto max-w-4xl px-4 sm:px-6">
            <Card className="flex flex-col items-center gap-6 p-10 text-center">
              <h2 className="text-balance text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
                Audit your website now
              </h2>
              <p className="max-w-md text-pretty text-muted-foreground">
                See exactly what&apos;s holding back your conversions — for free, in under a minute.
              </p>
              <Button size="lg" asChild>
                <Link href="/sign-up">
                  Get started
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
            </Card>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}

function HeroPreview() {
  return (
    <Card className="relative overflow-hidden p-6 shadow-xl">
      <div className="flex items-center justify-between border-b border-border pb-4">
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground">Audit results</p>
          <p className="truncate font-medium text-foreground">https://acme-store.com</p>
        </div>
        <span className="rounded-full bg-accent px-2.5 py-1 text-xs font-medium text-accent-foreground">Completed</span>
      </div>

      <div className="flex items-center justify-center py-6">
        <ScoreRing score={82} size={140} label="Overall" />
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "SEO", score: 91 },
          { label: "Accessibility", score: 74 },
          { label: "Performance", score: 80 },
        ].map((s) => (
          <div key={s.label} className="rounded-lg border border-border bg-background p-3 text-center">
            <ScoreRing score={s.score} size={64} strokeWidth={6} />
            <p className="mt-2 text-xs font-medium text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-lg border border-border bg-accent/40 p-3">
        <p className="flex items-center gap-2 text-xs font-medium text-foreground">
          <Sparkles className="size-3.5 text-primary" />
          AI recommendation
        </p>
        <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
          Add alt text to 6 product images and compress your hero banner to lift performance and accessibility.
        </p>
      </div>
    </Card>
  )
}
