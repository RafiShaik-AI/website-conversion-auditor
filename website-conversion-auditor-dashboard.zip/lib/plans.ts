export type Plan = {
  id: "free" | "pro" | "agency"
  name: string
  price: string
  period: string
  description: string
  features: string[]
  cta: string
  highlighted?: boolean
}

export const plans: Plan[] = [
  {
    id: "free",
    name: "Starter",
    price: "$0",
    period: "forever",
    description: "Run quick audits for a single site and explore the platform.",
    features: ["5 audits per month", "SEO, accessibility & performance scores", "Basic issue detection", "1 user"],
    cta: "Start free",
  },
  {
    id: "pro",
    name: "Pro",
    price: "$29",
    period: "per month",
    description: "For founders and marketers serious about conversion.",
    features: [
      "Unlimited audits",
      "AI-powered recommendations",
      "Branded PDF reports",
      "Audit history & trends",
      "Priority analysis queue",
    ],
    cta: "Upgrade to Pro",
    highlighted: true,
  },
  {
    id: "agency",
    name: "Agency",
    price: "$99",
    period: "per month",
    description: "For agencies auditing many client websites at scale.",
    features: [
      "Everything in Pro",
      "White-label PDF reports",
      "Up to 10 team members",
      "Bulk audits",
      "Dedicated support",
    ],
    cta: "Contact sales",
  },
]
