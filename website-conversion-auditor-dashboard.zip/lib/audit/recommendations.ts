import { generateText } from "ai"
import type { AnalysisResult } from "@/lib/audit/analyze"

export async function generateRecommendations(analysis: AnalysisResult): Promise<string> {
  const issueList =
    analysis.issues.length > 0
      ? analysis.issues
          .map((i) => `- [${i.category}/${i.severity}] ${i.title}: ${i.description}`)
          .join("\n")
      : "No major issues were detected by the automated scan."

  const prompt = `You are a senior conversion rate optimization (CRO) consultant reviewing an automated website audit.

Website: ${analysis.url}
Scores (0-100): SEO ${analysis.seoScore}, Accessibility ${analysis.accessibilityScore}, Performance ${analysis.performanceScore}, Overall ${analysis.overallScore}.

Detected signals:
- Title: ${analysis.metrics.title ?? "missing"}
- Meta description: ${analysis.metrics.description ? "present" : "missing"}
- Words: ${analysis.metrics.wordCount}
- Images: ${analysis.metrics.imageCount} (${analysis.metrics.imagesMissingAlt} missing alt)
- Scripts: ${analysis.metrics.scriptCount}
- HTML size: ${Math.round(analysis.metrics.pageBytes / 1024)} KB
- Response time: ${analysis.metrics.loadMs} ms
- HTTPS: ${analysis.metrics.hasHttps}, Viewport: ${analysis.metrics.hasViewport}, Lang: ${analysis.metrics.hasLangAttr}

Detected issues:
${issueList}

Write a concise, prioritized action plan to improve this site's conversion rate, SEO, accessibility, and performance.
Format your response in clean Markdown with:
1. A one-paragraph executive summary.
2. A "Top Priorities" section with 3-5 bullet points, each starting with a bold action.
3. A short "Quick Wins" section.
Be specific and practical. Do not invent metrics that weren't provided.`

  try {
    const { text } = await generateText({
      model: "openai/gpt-5-mini",
      prompt,
      maxOutputTokens: 900,
    })
    return text.trim()
  } catch (err) {
    console.log("[v0] AI recommendation generation failed:", err instanceof Error ? err.message : err)
    // Graceful fallback so an audit is never blocked by the AI step.
    return fallbackRecommendations(analysis)
  }
}

function fallbackRecommendations(analysis: AnalysisResult): string {
  const priorities = analysis.issues
    .filter((i) => i.severity !== "info")
    .slice(0, 5)
    .map((i) => `- **${i.title}.** ${i.description}`)
    .join("\n")

  return `## Executive Summary

Your site scored **${analysis.overallScore}/100** overall. Focus on the highest-severity issues below to improve discoverability, usability, and conversion.

## Top Priorities

${priorities || "- No critical issues detected. Maintain your current best practices and monitor regularly."}

## Quick Wins

- Compress and lazy-load images to speed up first render.
- Ensure every page has a unique title and meta description.
- Add descriptive alt text to all meaningful images.`
}
