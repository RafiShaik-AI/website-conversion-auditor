import { jsPDF } from "jspdf"
import type { Audit } from "@/lib/db/schema"

const BRAND: [number, number, number] = [22, 142, 105]
const TEXT: [number, number, number] = [30, 41, 46]
const MUTED: [number, number, number] = [110, 120, 118]

function scoreRGB(score: number): [number, number, number] {
  if (score >= 90) return [22, 142, 105]
  if (score >= 50) return [196, 145, 30]
  return [200, 60, 50]
}

export function generateAuditPdf(audit: Audit) {
  const doc = new jsPDF({ unit: "pt", format: "a4" })
  const pageWidth = doc.internal.pageSize.getWidth()
  const margin = 48
  let y = margin

  // Header bar
  doc.setFillColor(...BRAND)
  doc.rect(0, 0, pageWidth, 8, "F")

  doc.setFont("helvetica", "bold")
  doc.setFontSize(20)
  doc.setTextColor(...TEXT)
  doc.text("Website Conversion Audit", margin, (y += 24))

  doc.setFont("helvetica", "normal")
  doc.setFontSize(11)
  doc.setTextColor(...MUTED)
  doc.text(audit.url, margin, (y += 18))
  doc.text(
    `Generated ${new Date(audit.createdAt).toLocaleString(undefined, { dateStyle: "long", timeStyle: "short" })}`,
    margin,
    (y += 15),
  )

  // Overall score
  y += 24
  doc.setDrawColor(225, 230, 228)
  doc.setLineWidth(1)
  doc.line(margin, y, pageWidth - margin, y)
  y += 28

  doc.setFont("helvetica", "bold")
  doc.setFontSize(40)
  doc.setTextColor(...scoreRGB(audit.overallScore))
  doc.text(String(audit.overallScore), margin, y)
  doc.setFontSize(11)
  doc.setTextColor(...MUTED)
  doc.text("/ 100 overall conversion score", margin + 70, y - 6)

  // Score breakdown
  y += 30
  const cols = [
    { label: "SEO", score: audit.seoScore },
    { label: "Accessibility", score: audit.accessibilityScore },
    { label: "Performance", score: audit.performanceScore },
  ]
  const colWidth = (pageWidth - margin * 2) / 3
  cols.forEach((c, i) => {
    const x = margin + i * colWidth
    doc.setFont("helvetica", "bold")
    doc.setFontSize(22)
    doc.setTextColor(...scoreRGB(c.score))
    doc.text(String(c.score), x, y)
    doc.setFont("helvetica", "normal")
    doc.setFontSize(10)
    doc.setTextColor(...MUTED)
    doc.text(c.label, x, y + 16)
  })

  // Issues
  y += 48
  const issues = audit.issues ?? []
  doc.setFont("helvetica", "bold")
  doc.setFontSize(14)
  doc.setTextColor(...TEXT)
  doc.text(`Detected Issues (${issues.length})`, margin, y)
  y += 8

  issues.forEach((issue) => {
    if (y > 740) {
      doc.addPage()
      y = margin
    }
    y += 20
    doc.setFont("helvetica", "bold")
    doc.setFontSize(10)
    doc.setTextColor(...TEXT)
    doc.text(`[${issue.category.toUpperCase()} · ${issue.severity}]`, margin, y)
    doc.setFont("helvetica", "bold")
    doc.text(issue.title, margin + 130, y)
    y += 14
    doc.setFont("helvetica", "normal")
    doc.setTextColor(...MUTED)
    const lines = doc.splitTextToSize(issue.description, pageWidth - margin * 2)
    doc.text(lines, margin, y)
    y += lines.length * 12
  })

  if (issues.length === 0) {
    y += 18
    doc.setFont("helvetica", "normal")
    doc.setFontSize(10)
    doc.setTextColor(...MUTED)
    doc.text("No major issues detected. Great work!", margin, y)
  }

  // Recommendations
  if (audit.recommendations) {
    doc.addPage()
    y = margin
    doc.setFillColor(...BRAND)
    doc.rect(0, 0, pageWidth, 8, "F")
    doc.setFont("helvetica", "bold")
    doc.setFontSize(14)
    doc.setTextColor(...TEXT)
    doc.text("AI Recommendations", margin, (y += 20))
    y += 8
    doc.setFont("helvetica", "normal")
    doc.setFontSize(10)
    doc.setTextColor(...TEXT)
    // strip basic markdown markers for the PDF
    const clean = audit.recommendations.replace(/[#*`>]/g, "").replace(/\n{2,}/g, "\n\n")
    const lines = doc.splitTextToSize(clean, pageWidth - margin * 2)
    lines.forEach((line: string) => {
      if (y > 780) {
        doc.addPage()
        y = margin
      }
      y += 14
      doc.text(line, margin, y)
    })
  }

  const safeName = audit.url.replace(/^https?:\/\//, "").replace(/[^a-z0-9]/gi, "-").slice(0, 40)
  doc.save(`audit-${safeName}.pdf`)
}
