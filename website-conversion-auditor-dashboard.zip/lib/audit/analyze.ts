import type { AuditIssue, AuditMetrics } from "@/lib/db/schema"

export type AnalysisResult = {
  url: string
  metrics: AuditMetrics
  issues: AuditIssue[]
  seoScore: number
  accessibilityScore: number
  performanceScore: number
  overallScore: number
}

export function normalizeUrl(input: string): string {
  let url = input.trim()
  if (!/^https?:\/\//i.test(url)) {
    url = `https://${url}`
  }
  // Throws if invalid
  const parsed = new URL(url)
  return parsed.toString()
}

function countMatches(html: string, regex: RegExp): number {
  const matches = html.match(regex)
  return matches ? matches.length : 0
}

function clamp(n: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, Math.round(n)))
}

export async function analyzeWebsite(rawUrl: string): Promise<AnalysisResult> {
  const url = normalizeUrl(rawUrl)

  const start = Date.now()
  let html = ""
  let ok = false
  let status = 0

  try {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 15000)
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; ConversionAuditorBot/1.0; +https://conversionauditor.app)",
        Accept: "text/html,application/xhtml+xml",
      },
      cache: "no-store",
    })
    clearTimeout(timeout)
    status = res.status
    ok = res.ok
    html = await res.text()
  } catch (err) {
    throw new Error(
      `Could not reach ${url}. The site may be down, blocking automated requests, or unreachable. (${
        err instanceof Error ? err.message : "network error"
      })`,
    )
  }

  const loadMs = Date.now() - start

  if (!ok) {
    throw new Error(`The site responded with HTTP ${status}. Unable to complete the audit.`)
  }

  const pageBytes = new TextEncoder().encode(html).length

  // --- Extract signals ------------------------------------------------------
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)
  const title = titleMatch ? titleMatch[1].trim().replace(/\s+/g, " ") : null

  const descMatch = html.match(/<meta[^>]+name=["']description["'][^>]*>/i)
  let description: string | null = null
  if (descMatch) {
    const content = descMatch[0].match(/content=["']([^"']*)["']/i)
    description = content ? content[1].trim() : null
  }

  const imgTags = html.match(/<img\b[^>]*>/gi) ?? []
  const imageCount = imgTags.length
  const imagesMissingAlt = imgTags.filter((tag) => !/\balt\s*=/i.test(tag)).length

  const linkCount = countMatches(html, /<a\b[^>]*href=/gi)
  const headingCount = countMatches(html, /<h[1-6]\b/gi)
  const h1Count = countMatches(html, /<h1\b/gi)
  const scriptCount = countMatches(html, /<script\b/gi)

  const hasViewport = /<meta[^>]+name=["']viewport["']/i.test(html)
  const hasHttps = url.startsWith("https://")
  const hasLangAttr = /<html[^>]+lang=/i.test(html)

  // rough word count of visible text
  const text = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
  const wordCount = text ? text.split(" ").length : 0

  const metrics: AuditMetrics = {
    title,
    description,
    pageBytes,
    loadMs,
    imageCount,
    imagesMissingAlt,
    linkCount,
    headingCount,
    h1Count,
    scriptCount,
    hasViewport,
    hasHttps,
    hasLangAttr,
    wordCount,
  }

  const issues: AuditIssue[] = []

  // --- SEO scoring ----------------------------------------------------------
  let seo = 100
  if (!title) {
    seo -= 25
    issues.push({
      category: "seo",
      severity: "critical",
      title: "Missing page title",
      description: "The page has no <title> tag. Titles are critical for search rankings and click-through rates.",
    })
  } else if (title.length < 15 || title.length > 65) {
    seo -= 8
    issues.push({
      category: "seo",
      severity: "warning",
      title: "Title length is not optimal",
      description: `Your title is ${title.length} characters. Aim for 15–65 characters so it displays fully in search results.`,
    })
  }

  if (!description) {
    seo -= 18
    issues.push({
      category: "seo",
      severity: "warning",
      title: "Missing meta description",
      description: "Add a meta description (120–160 chars) to improve search snippets and click-through rate.",
    })
  } else if (description.length < 70 || description.length > 165) {
    seo -= 6
    issues.push({
      category: "seo",
      severity: "info",
      title: "Meta description length is off",
      description: `Description is ${description.length} characters. The ideal range is 120–160 characters.`,
    })
  }

  if (h1Count === 0) {
    seo -= 15
    issues.push({
      category: "seo",
      severity: "warning",
      title: "No H1 heading found",
      description: "Every page should have exactly one H1 that describes the main topic.",
    })
  } else if (h1Count > 1) {
    seo -= 6
    issues.push({
      category: "seo",
      severity: "info",
      title: "Multiple H1 headings",
      description: `Found ${h1Count} H1 tags. Use a single H1 per page for a clear content hierarchy.`,
    })
  }

  if (wordCount < 250) {
    seo -= 10
    issues.push({
      category: "seo",
      severity: "info",
      title: "Thin content",
      description: `Only ~${wordCount} words detected. Pages with richer content tend to rank better.`,
    })
  }

  if (!hasHttps) {
    seo -= 10
    issues.push({
      category: "seo",
      severity: "critical",
      title: "Not served over HTTPS",
      description: "HTTPS is a confirmed ranking signal and required for user trust.",
    })
  }

  // --- Accessibility scoring ------------------------------------------------
  let a11y = 100
  if (imageCount > 0 && imagesMissingAlt > 0) {
    const penalty = Math.min(35, Math.round((imagesMissingAlt / imageCount) * 50))
    a11y -= penalty
    issues.push({
      category: "accessibility",
      severity: imagesMissingAlt / imageCount > 0.5 ? "critical" : "warning",
      title: "Images missing alt text",
      description: `${imagesMissingAlt} of ${imageCount} images have no alt attribute. Screen readers cannot describe them.`,
    })
  }

  if (!hasLangAttr) {
    a11y -= 15
    issues.push({
      category: "accessibility",
      severity: "warning",
      title: "Missing lang attribute",
      description: "Add a lang attribute to the <html> element so assistive tech announces the correct language.",
    })
  }

  if (!hasViewport) {
    a11y -= 15
    issues.push({
      category: "accessibility",
      severity: "warning",
      title: "No responsive viewport meta tag",
      description: "Without a viewport meta tag, the site may be hard to use and zoom on mobile devices.",
    })
  }

  if (headingCount === 0) {
    a11y -= 12
    issues.push({
      category: "accessibility",
      severity: "warning",
      title: "No heading structure",
      description: "Headings give screen-reader users a navigable outline of the page.",
    })
  }

  // --- Performance scoring --------------------------------------------------
  let perf = 100
  const pageKb = pageBytes / 1024
  if (pageKb > 2048) {
    perf -= 30
    issues.push({
      category: "performance",
      severity: "critical",
      title: "Very large HTML payload",
      description: `The HTML document is ${(pageKb / 1024).toFixed(1)} MB. Large pages slow down first render dramatically.`,
    })
  } else if (pageKb > 500) {
    perf -= 15
    issues.push({
      category: "performance",
      severity: "warning",
      title: "Heavy HTML payload",
      description: `The HTML is ${Math.round(pageKb)} KB. Consider trimming inline markup and deferring content.`,
    })
  }

  if (loadMs > 2500) {
    perf -= 25
    issues.push({
      category: "performance",
      severity: "critical",
      title: "Slow server response",
      description: `The document took ${loadMs} ms to download. Aim for under 800 ms time-to-first-byte.`,
    })
  } else if (loadMs > 1000) {
    perf -= 12
    issues.push({
      category: "performance",
      severity: "warning",
      title: "Sluggish response time",
      description: `Response took ${loadMs} ms. Caching and a CDN can bring this down.`,
    })
  }

  if (scriptCount > 25) {
    perf -= 15
    issues.push({
      category: "performance",
      severity: "warning",
      title: "Too many script tags",
      description: `${scriptCount} <script> tags found. Bundle and defer scripts to reduce blocking time.`,
    })
  } else if (scriptCount > 12) {
    perf -= 7
    issues.push({
      category: "performance",
      severity: "info",
      title: "Many script tags",
      description: `${scriptCount} scripts detected. Review whether all are needed on initial load.`,
    })
  }

  const seoScore = clamp(seo)
  const accessibilityScore = clamp(a11y)
  const performanceScore = clamp(perf)
  const overallScore = clamp((seoScore + accessibilityScore + performanceScore) / 3)

  return {
    url,
    metrics,
    issues,
    seoScore,
    accessibilityScore,
    performanceScore,
    overallScore,
  }
}
