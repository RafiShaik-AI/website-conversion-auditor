import { pgTable, text, timestamp, boolean, serial, integer, jsonb } from "drizzle-orm/pg-core"

// --- Better Auth required tables -------------------------------------------
// Column names are camelCase to match Better Auth's defaults. Do not rename.

export const user = pgTable("user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("emailVerified").notNull().default(false),
  image: text("image"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expiresAt").notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
})

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("accountId").notNull(),
  providerId: text("providerId").notNull(),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow(),
})

// --- App tables ------------------------------------------------------------

export const audits = pgTable("audits", {
  id: serial("id").primaryKey(),
  userId: text("userId").notNull(),
  url: text("url").notNull(),
  status: text("status").notNull().default("completed"),
  seoScore: integer("seoScore").notNull().default(0),
  accessibilityScore: integer("accessibilityScore").notNull().default(0),
  performanceScore: integer("performanceScore").notNull().default(0),
  overallScore: integer("overallScore").notNull().default(0),
  metrics: jsonb("metrics").$type<AuditMetrics | null>(),
  issues: jsonb("issues").$type<AuditIssue[] | null>(),
  recommendations: text("recommendations"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
})

export const userSettings = pgTable("user_settings", {
  userId: text("userId").primaryKey(),
  plan: text("plan").notNull().default("free"),
  company: text("company"),
  emailReports: boolean("emailReports").notNull().default(true),
  weeklyDigest: boolean("weeklyDigest").notNull().default(false),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export type AuditMetrics = {
  title: string | null
  description: string | null
  pageBytes: number
  loadMs: number
  imageCount: number
  imagesMissingAlt: number
  linkCount: number
  headingCount: number
  h1Count: number
  scriptCount: number
  hasViewport: boolean
  hasHttps: boolean
  hasLangAttr: boolean
  wordCount: number
}

export type AuditIssue = {
  category: "seo" | "accessibility" | "performance"
  severity: "critical" | "warning" | "info"
  title: string
  description: string
}

export type Audit = typeof audits.$inferSelect
export type UserSettings = typeof userSettings.$inferSelect
